<?php
// Estabelecer a conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "registro";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar se houve erro na conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Criar a tabela moradores caso não exista
$sql_moradores = "CREATE TABLE IF NOT EXISTS moradores (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(11) NOT NULL,
    tipo_condominio ENUM('apartamento', 'casa') NOT NULL,
    bloco VARCHAR(10) NOT NULL,
    numero_apto INT NOT NULL
)";

if ($conn->query($sql_moradores) === FALSE) {
    die("Erro ao criar a tabela moradores: " . $conn->error);
}

// Criar a tabela visitantes caso não exista
$sql_visitantes = "CREATE TABLE IF NOT EXISTS visitantes (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(11) NOT NULL,
    tipo_usuario VARCHAR(50) NOT NULL,
    registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql_visitantes) === FALSE) {
    die("Erro ao criar a tabela visitantes: " . $conn->error);
}

// Inserir dados de moradores
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_morador'])) {
    $nome = filter_var($_POST['nome'], FILTER_SANITIZE_STRING);
    $cpf = filter_var($_POST['cpf'], FILTER_SANITIZE_STRING);
    $condominio = filter_var($_POST['condominio'], FILTER_SANITIZE_STRING);
    $numeroApto = filter_var($_POST['numero_apto'], FILTER_SANITIZE_STRING);
    $bloco = filter_var($_POST['bloco'], FILTER_SANITIZE_STRING);

    $stmt = $conn->prepare("INSERT INTO moradores (nome, cpf, condominio, numero_apto, bloco) VALUES (?, ?, ?, ?, ?)");
    if ($stmt === false) {
        die("Erro na preparação da declaração: " . $conn->error);
    }
    $stmt->bind_param("sssss", $nome, $cpf, $condominio, $numeroApto, $bloco);

    if ($stmt->execute()) {
        echo "Novo registro de morador criado com sucesso";
    } else {
        echo "Erro ao criar registro de morador: " . $stmt->error;
    }

    $stmt->close();
}

// Inserir dados de visitantes
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_visitante'])) {
    $nome = filter_var($_POST['nome_completo'], FILTER_SANITIZE_STRING);
    $cpf = filter_var($_POST['cpf'], FILTER_SANITIZE_STRING);
    $tipoUsuario = filter_var($_POST['tipo_usuario'], FILTER_SANITIZE_STRING);

    $stmt = $conn->prepare("INSERT INTO visitantes (nome, cpf, tipo_usuario) VALUES (?, ?, ?)");
    if ($stmt === false) {
        die("Erro na preparação da declaração: " . $conn->error);
    }
    $stmt->bind_param("sss", $nome, $cpf, $tipoUsuario);

    if ($stmt->execute()) {
        echo "Novo registro de visitante criado com sucesso";
    } else {
        echo "Erro ao criar registro de visitante: " . $stmt->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Portaria Inteligente</title>
    <link rel="stylesheet" href="estilos/tabelaRegistro.css">
</head>
<body>
<header>
    <div class="interface">
        <div class="logo">
            <img src="img/logoP.png" alt="logo do site">
        </div><!--logo-->
        <h1>Portaria Inteligente</h1>
    </div><!--interface-->
</header>
<br><br><br>
<h2>Moradores</h2>
<table border="1">
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>CPF</th>
        <th>Condomínio</th>
        <th>Bloco</th>
        <th>Número</th>
    </tr>
    <?php
    // Buscar registros de moradores
    $sql = 'SELECT * FROM moradores';
    $resultado = $conn->query($sql);

    // Verificar se a query foi bem-sucedida
    if ($resultado === false) {
        die("Erro na query: " . $conn->error);
    }

    // Exibir registros retornados
    if ($resultado->num_rows > 0) {
        while ($row = $resultado->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8') . "</td>";
            echo "<td>" . htmlspecialchars($row['nome'], ENT_QUOTES, 'UTF-8') . "</td>";
            echo "<td>" . htmlspecialchars($row['cpf'], ENT_QUOTES, 'UTF-8') . "</td>";
            echo "<td>" . htmlspecialchars($row['tipo_condominio'], ENT_QUOTES, 'UTF-8') . "</td>";
            echo "<td>" . htmlspecialchars($row['bloco'], ENT_QUOTES, 'UTF-8') . "</td>";
            echo "<td>" . htmlspecialchars($row['numero_apto'], ENT_QUOTES, 'UTF-8') . "</td>";
        }
    } else {
        echo "<tr><td colspan='7'>Nenhum registro encontrado</td></tr>";
    }
    ?>
</table>

<h3>Visitantes</h3>
<table border="1">
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>CPF</th>
        <th>Tipo de Usuário</th>
        <th>Registro</th>
    </tr>
    <?php
    // Buscar registros de visitantes
    $sql = 'SELECT * FROM visitantes';
    $resultado = $conn->query($sql);

    // Verificar se a query foi bem-sucedida
    if ($resultado === false) {
        die("Erro na query: " . $conn->error);
    }

    // Exibir registros retornados
    if ($resultado->num_rows > 0) {
        while ($row = $resultado->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['idvisitante'], ENT_QUOTES, 'UTF-8') . "</td>";
            echo "<td>" . htmlspecialchars($row['nome'], ENT_QUOTES, 'UTF-8') . "</td>";
            echo "<td>" . htmlspecialchars($row['cpf'], ENT_QUOTES, 'UTF-8') . "</td>";
            echo "<td>" . htmlspecialchars($row['tipo_usuario'], ENT_QUOTES, 'UTF-8') . "</td>";
            echo "<td>" . htmlspecialchars($row['registro'], ENT_QUOTES, 'UTF-8') . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='5'>Nenhum registro encontrado</td></tr>";
    }

    // Fechar a conexão
    $conn->close();
    ?>
</table>
</body>
</html>

