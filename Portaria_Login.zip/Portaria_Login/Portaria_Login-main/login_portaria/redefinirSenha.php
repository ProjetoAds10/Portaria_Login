<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portaria Inteligente - Redefinir Senha</title>
    <link rel="stylesheet" href="estilos/redefinirsenha.css">
</head>
<body>
    <div class="header">
        <img src="img/logoP.png" alt="Ícone de cadeado">
        <h1>Portaria inteligente</h1>
    </div>
    <div class="container">
        <div class="form-box">
            <h2>REDEFINIR SENHA SISTEMA PORTARIA</h2>
            <form action="reset_password.php" method="post">
                <input type="text" name="cpf" placeholder="CPF" required>
                <input type="password" name="senha" placeholder="SENHA" required>
                <input type="password" name="confirm_senha" placeholder="CONFIRMAR SENHA" required>
                <button type="submit">REDEFINIR</button>
            </form>
        </div>
    </div>
</body>
</html>
