<?php
// Estabelecer a conexão com o banco de dados
$conexao = new mysqli('localhost', 'root', '', 'registro');

// Verificar se houve erro na conexão
if ($conexao->connect_error) {
    die("Falha na conexão: " . $conexao->connect_error);
}

// Verificar se a requisição é POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $cpf = $_POST['cpf'];
    $userType = $_POST['userType'];
    $condominio = $_POST['condominio'];
    $bloco = $_POST['bloco'];
    $numero = $_POST['numero'];

    // Escapar os dados para evitar SQL Injection
    $name = $conexao->real_escape_string($name);
    $cpf = $conexao->real_escape_string($cpf);
    $userType = $conexao->real_escape_string($userType);
    $condominio = $conexao->real_escape_string($condominio);
    $bloco = $conexao->real_escape_string($bloco);
    $numero = $conexao->real_escape_string($numero);

    // Inserir os dados no banco de dados para Visitantes
    $sql = "INSERT INTO Visitantes (Nome, CPF, TipoUsuario, Condominio, Bloco, Numero) VALUES ('$name', '$cpf', '$userType', '$condominio', '$bloco', '$numero')";

    if ($conexao->query($sql) === TRUE) {
        // Redirecionar para a página tabelaRegistro.php após o sucesso
        header('Location: tabelaRegistro.php');
        exit();
    } else {
        echo "Erro ao registrar entrada: " . $conexao->error;
    }
} else {
    echo "Método de requisição inválido.";
}

$conexao->close();
?>
