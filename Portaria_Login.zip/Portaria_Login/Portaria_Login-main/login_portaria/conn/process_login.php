<?php
// process_login.php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $userType = $_POST['userType'];
    $name = $_POST['name'];
    $cpf = $_POST['cpf'];

    // Exemplo de verificação simples (substitua com a lógica de autenticação real)
    if ($userType && $name && $cpf) {
        echo "Entrada registrada com sucesso para $name!";
    } else {
        echo "Erro ao registrar a entrada. Verifique os dados.";
    }
} else {
    echo "Método de requisição inválido.";
}
