<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome_completo = $_POST['nome_completo'];
    $cpf = $_POST['cpf'];
    $condominio = $_POST['condominio'];
    $numero_apartamento = $_POST['numero_apartamento'];
    $bloco = $_POST['bloco'];

    // Aqui você pode adicionar o código para processar os dados, por exemplo, salvá-los em um banco de dados
    // Para demonstração, vamos apenas exibir os dados
    echo "Nome Completo: " . htmlspecialchars($nome_completo) . "<br>";
    echo "CPF: " . htmlspecialchars($cpf) . "<br>";
    echo "Condomínio: " . htmlspecialchars($condominio) . "<br>";
    echo "Nº Apartamento: " . htmlspecialchars($numero_apartamento) . "<br>";
    echo "Bloco: " . htmlspecialchars($bloco) . "<br>";
}
?>
