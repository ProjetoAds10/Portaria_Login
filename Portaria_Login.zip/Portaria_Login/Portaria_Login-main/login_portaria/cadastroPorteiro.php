<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portaria Inteligente</title>
    <link rel="stylesheet" href="estilos/cadastroPorteiro.css">
</head>

<body>
    <div class="header">
        <img src="img/logoP.png" alt="Ícone de cadeado">
        <h1>Portaria inteligente</h1>
    </div>
    <div class="container">
        <div class="form-box">
            <h2>CADASTRAR SISTEMA PORTARIA</h2>
            <form>
                <input type="text" name="nome" placeholder="Nome">
                <input type="text" name="cpf" placeholder="CPF">
                <input type="password" name="senha" placeholder="Senha">
                <button type="submit">CADASTRAR</button>
            </form>
        </div>
    </div>
</body>

</html>



<?php
//tela de cadastro do proteiro

include 'conn/configPorteiro.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $cpf = $_POST['cpf'];
    $password = $_POST['senha'];

    //Inserir no banco de dados
    $sql = "INSERT INTO moradores (cpf, senha) VALUES ()";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("$cpf, $password") or die("" . $sql);
    $stmt->execute();
}

?>