<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Morador</title>
    <link rel="stylesheet" href="estilos/cadastroMoradores.css">
</head>
<body>
<header>
    <div class="interface">
        <div class="logo">
            <img src="img/logoP.png" alt="logo do site">
        </div><!--logo-->
        <h1>Portaria Inteligente</h1>
    </div><!--interface-->
</header>
<br><br><br><br><br>
<div class="container">
    <h2>Cadastro de Morador</h2>
    <form action="tabelaRegistro.php" method="post">
        <div class="form-group">
            <label for="nome">Nome Completo</label>
            <input type="text" id="nome" name="nome" placeholder="" required>
        </div>
        
        <div class="form-group">
            <label for="cpf">CPF</label> 
            <input type="text" id="cpf" name="cpf" placeholder="" required>
        </div>
        <div class="form-group"> 
            <label for="condominio">Condomínio</label> 
            <input type="text" id="condominio" name="condominio" placeholder="" required>
        </div>
        <div class="form-group"> 
            <label for="numero_apto">Nº Apartamento</label> 
            <input type="text" id="numero_apto" name="numero_apto" placeholder="" required>
        </div>
        <div class="form-group">
            <label for="bloco">Bloco</label>
            <input type="text" id="bloco" name="bloco" placeholder="" required>
        </div>
        <div class="button">
            <button type="submit" name="submit_morador">CADASTRAR</button>
        </div>
    </form>
</div>
</body>
</html>


