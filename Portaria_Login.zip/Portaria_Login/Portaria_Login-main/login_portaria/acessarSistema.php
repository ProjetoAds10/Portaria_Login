<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acessar Sistema</title>
    <link rel="stylesheet" href="estilos/acessarporteiro.css">
</head>

<body>
    <header>
        <div class="interface">
            <div class="logo">
                <img src="img/logoP.png" alt="logo do site">
            </div><!--logo-->
            <h1>Portaria Inteligente</h1>
        </div><!--interface-->
    </header>

    <div class="container">
        <div class="header">
            <h1>ACESSAR SISTEMA PORTARIA</h1>
        </div><!--header-->

        <form action="entradaMorador_Visitante.php" method="POST">
            <div class="input">
                <label for="cpf">CPF</label>
                <input type="text" id="cpf" name="cpf" required>
                <span class="invalid-feedback"></span>
            </div><br>
            <div class="input">
                <label for="senha">SENHA</label>
                <input type="password" id="senha" name="senha" required>
                <span class="invalid-feedback"></span>
            </div><br><br>
            <div class="button">
                <button type="submit">ENTRAR</button>
                <button type="button" onclick="window.location.href='redefinirSenha.php'">REDEFINIR SENHA</button>
            </div><br>
            <div class="button">
                <button type="button" onclick="window.location.href='cadastroPorteiro.php'">CADASTRAR</button>

            </div>
        </form>
    </div>

</body>

</html>


<?php

include 'conn/configPorteiro.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cpf = $_POST['cpf'];
    $senha = $_POST['senha'];
} else {
    //Verificar usuario e a senha
    $sql = "SELECT senha FROM moradores WHERE cpf = ?" . "";
}
?>
