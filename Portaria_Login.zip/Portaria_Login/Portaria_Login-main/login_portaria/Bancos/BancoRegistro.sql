SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

CREATE DATABASE registro;
USE registro;

CREATE TABLE moradores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cpf CHAR(11) NOT NULL UNIQUE,
    condominio VARCHAR(100) NOT NULL,
    tipo_condominio ENUM('apartamento', 'casa') NOT NULL,
    bloco VARCHAR(10) NOT NULL,
    numero_apto INT NOT NULL,
    
    -- Verifica que "bloco" não pode ser nulo para "apartamento", mas permite nulo para "casa"
    CONSTRAINT bloco_obrigatorio CHECK (
        (tipo_condominio = 'apartamento' AND bloco IS NOT NULL) OR
        (tipo_condominio = 'casa' AND bloco IS NULL)
    )
);

CREATE TABLE visitante (
    idvisitante INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    cpf CHAR(11) NOT NULL,
    TipoUsuario VARCHAR(50) NOT NULL, -- Adicionando a coluna TipoUsuario
    PRIMARY KEY (idvisitante)
) ENGINE=InnoDB;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;