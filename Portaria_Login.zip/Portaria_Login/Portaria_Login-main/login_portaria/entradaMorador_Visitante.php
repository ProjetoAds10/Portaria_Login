<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portaria Inteligente - Login</title>
    <link rel="stylesheet" href="estilos/EntradaMorador.css">
</head>
<body>
<header>
    <div class="interface">
        <div class="logo">
            <img src="img/logoP.png" alt="logo do site">
        </div><!--logo-->
        <h1>Portaria Inteligente</h1>
    </div><!--interface-->
</header>

<!-- Conteúdo principal centralizado na tela -->
<div class="main-content">
    <div class="container">
        <h2>Entrada moradores e visitantes</h2>
        <form action="process_login.php" method="POST">
            <div class="form-group">
                <label for="userType">Morador/Visitante</label>
                <input type="text" id="userType" name="userType" required>
            </div>
            <div class="form-group">
                <label for="name">Nome</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="cpf">CPF/Código de Validação</label>
                <input type="text" id="cpf" name="cpf" required>
            </div>
            <button type="submit" class="button button-primary">Registrar Entrada</button>
            <button type="button" class="button button-secondary" onclick="window.location.href='CadastroMoradores.php'">Cadastrar Morador</button>
        </form>
    </div>
</div>
</body>
</html>

