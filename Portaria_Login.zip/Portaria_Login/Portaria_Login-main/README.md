# Portaria_Login
login portaria



git init
git add README.md
git commit -m "first commit"
git branch -M main
git remote add origin [https://github.com/ProjetoAds10/Portaria_Login]
git push -u origin main

git branch -M main
git push -u origin main
